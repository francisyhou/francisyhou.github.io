function [link_RG,degree_Rank]=Relationship_Graph(casename,link_num)

%Relationship graph(RG) construction based on failure counting.
% clc,clear



 
link_raw=casename;


for ii=1:1


% link_num=46; %set in light of cases
link_failure_sum=zeros(1,link_num); %sum of failure in each link

link_failure_order=zeros(link_num,20); %sum of failure in each link in each order
link_RG_initial=zeros(link_num);
for i=1:length(link_raw)
    link_sub=link_raw{i};
    for j=1:size(link_sub,1)
        
        %constrcution of RG
        h=1;
        if isempty(link_sub{j,h+1})
            index_temp1=link_sub{j,h}; %root failure
            link_failure_order(index_temp1,h)=link_failure_order(index_temp1,h)+1;
%             link_RG_initial(index_temp1,index_temp1)=link_RG_initial(index_temp1,index_temp1)+1;
        else
            while ~isempty(link_sub{j,h})
                index_temp1=link_sub{j,h}; %root failure
                index_temp2=link_sub{j,h+1};%leaf failure
                if h==1
                    link_failure_order(index_temp1,h)=link_failure_order(index_temp1,h)+1;
%                     link_RG_initial(index_temp1,index_temp1)=link_RG_initial(index_temp1,index_temp1)+1;
                end                
                if ~isempty(index_temp2)
                    link_failure_order(index_temp2,h+1)=link_failure_order(index_temp2,h+1)+1;
                    link_RG_initial(index_temp1,index_temp2)=link_RG_initial(index_temp1,index_temp2)+1;%sum of link failures
                end
                h=h+1;
            end
            %         if ~isempty(link_sub{j,2})
            %             link_failure_order(index_temp2,h)=link_failure_order(index_temp2,h)+1; %count the last order
            %         end
        end
    end
end
link_failure_sum=sum(link_failure_order,2);

%refine of RG
link_RG=link_RG_initial;
for i=1:size(link_failure_sum)
    if link_failure_sum(i)==0
%         link_RG(i,:)=link_RG(i,:)+0.0000000001;
    else
        link_RG(i,:)=link_RG(i,:)/link_failure_sum(i);
%         temp=find(link_RG(i,:)==0);
%         link_RG(i,temp)=link_RG(i,temp)+0.0000000001;
    end
end

%trasformation from graph to dividual node or link set.
% [ node, link ] =adj2binc(link_RG);

%%ָ�����
%Average Weighting Degree
out_degree=sum(link_RG,2);
degree_Rank=[1:link_num]';
degree_Rank=[degree_Rank,out_degree];
degree_Rank=sortrows(degree_Rank,-2);
% AWD=sum(out_degree)/link_num;

% %Average Clustering Coefficient 
% for i=1:link_num
%     cc(i)=0;
%     for j=1:link_num
%         for k=1:link_num
%             cc(i)=cc(i)+link_RG(i,j)*link_RG(j,k)*link_RG(k,i);
%         end
%     end
%     cc(i)=cc(i)/out_degree(i)/(out_degree(i)-1);
% end
% ACC=sum(cc)/link_num;


end
% figure
% loglog(xx(1,:),cc(1,:),'bo',xx(2,:),cc(2,:),'gx',xx(3,:),cc(3,:),'r+',xx(4,:),cc(4,:),'y*');
% axis([10^-2.5 10^1.6 10^-5 10^0]) 
% % title('ͼ������');
% xlabel('Out-degree');
% ylabel('Complementary Cumulative Probability Distribution');
% legend('��=0.4','��=0.6','��=0.8','��=1.0');
% 
% figure
% plot(xx(1,:),cc(1,:),'bo',xx(2,:),cc(2,:),'gx',xx(3,:),cc(3,:),'r+',xx(4,:),cc(4,:),'y*');
% axis([0 20 0 1]) 
% xlabel('Out-degree');
% ylabel('Complementary Cumulative Probability Distribution');
% legend('��=0.4','��=0.6','��=0.8','��=1.0');

% num=numel(CDF);
% [b x]=hist(CDF,300);
% % figure;plot(x,b/num);%�����ܶ�
% c=1-cumsum(b/num);%�ۻ��ֲ�
% axis([10e-2,10e2,10e-15,10e0]);
% plot(x,c);
% figure;
% % semilogx(x, c, 'o');
end
