function Value=GetStepValue(Grid,VaribleString,step)
try
    eval(['Value=',VaribleString,'.Step_',num2str(step),';']);
catch
    Value=[];
end