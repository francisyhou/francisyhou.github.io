function Grid=UpdateStepValue(Grid,VaribleString,step,value)
eval([VaribleString,'.Step_',num2str(step),'=value;']);