function varargout = hits(varargin)
% HITS MATLAB code for hits.fig
%      HITS, by itself, creates a new HITS or raises the existing
%      singleton*.
%
%      H = HITS returns the handle to a new HITS or the handle to
%      the existing singleton*.
%
%      HITS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HITS.M with the given input arguments.
%
%      HITS('Property','Value',...) creates a new HITS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hits_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hits_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hits

% Last Modified by GUIDE v2.5 08-Aug-2021 23:04:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hits_OpeningFcn, ...
                   'gui_OutputFcn',  @hits_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hits is made visible.
function hits_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hits (see VARARGIN)

% Choose default command line output for hits
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hits wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = hits_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');

L=length(filename);
if L<6
    errodlg('Wrong File','File Open Error'); 
    return;
end
wenjian = [pathname filename];
set(handles.edit1,'string',wenjian);
test=filename(1,L-3:L);
switch test
    case 'xlsx'
      data=xlsread(wenjian);
      set(handles.uitable1,'data',data);
    case '.txt'
      fp =fopen(wenjian);
      Data=textscan(fp,'%d%d%d%*[^\n]','delimiter',',','headerlines',1);
      fclose(fp);
      set(handles.uitable1,'Data',cell2mat(Data))
     otherwise
         msgbox('Wrong File','File Open Error'); 
         return;
end
handles.AreaData=Data;
guidata(hObject,handles);

function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function uitable2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uitable2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');

L=length(filename);
if L<6
    errodlg('Wrong File','File Open Error'); 
    return;
end
wenjian = [pathname filename];
set(handles.edit2,'string',wenjian);
test=filename(1,L-3:L);
switch test
    case 'xlsx'
      data=xlsread(wenjian);
      set(handles.uitable2,'data',data);
    case '.txt'
      fp =fopen(wenjian);
      Data=textscan(fp,'%.0f%.0f%.0f%f%f%*[^\n]','delimiter',',','headerlines',1);
      fclose(fp);
      set(handles.uitable2,'Data',cell2mat(Data))
     otherwise
         msgbox('Wrong File','File Open Error'); 
         return;
end
handles.BusData=Data;
guidata(hObject,handles);

function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');

L=length(filename);
if L<6
    errodlg('Wrong File','File Open Error'); 
    return;
end
wenjian = [pathname filename];
set(handles.edit3,'string',wenjian);
test=filename(1,L-3:L);
switch test
    case 'xlsx'
      data=xlsread(wenjian);
      set(handles.uitable1,'data',data);
    case '.txt'
      fp =fopen(wenjian);
      Data=textscan(fp,'%.0f%.0f%.0f%f%f%.0f%*[^\n]','delimiter',',','headerlines',1);
      fclose(fp);
      set(handles.uitable3,'Data',cell2mat(Data))
     otherwise
         msgbox('Wrong File','File Open Error'); 
         return;
end
handles.CriticalLoadData=Data;
guidata(hObject,handles);


function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');

L=length(filename);
if L<6
    errodlg('Wrong File','File Open Error'); 
    return;
end
wenjian = [pathname filename];
set(handles.edit4,'string',wenjian);
test=filename(1,L-3:L);
switch test
    case 'xlsx'
      data=xlsread(wenjian);
      set(handles.uitable4,'data',data);
    case '.txt'
      fp =fopen(wenjian);
      Data=textscan(fp,'%.0f%.0f%.0f%f%f%f%f%f%f%f%*[^\n]','delimiter',',','headerlines',1);
      fclose(fp);
      set(handles.uitable4,'Data',cell2mat(Data))
     otherwise
         msgbox('Wrong File','File Open Error'); 
         return;
end
handles.DispatchableLoadData=Data;
guidata(hObject,handles);

function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');

L=length(filename);
if L<6
    errodlg('Wrong File','File Open Error'); 
    return;
end
wenjian = [pathname filename];
set(handles.edit5,'string',wenjian);
test=filename(1,L-3:L);
switch test
    case 'xlsx'
      data=xlsread(wenjian);
      set(handles.uitable5,'data',data);
    case '.txt'
      fp =fopen(wenjian);
      Data=textscan(fp,'%.0f%.0f%.0f%f%.0f%f%f%f%f%f%f%.0f%*[^\n]','delimiter',',','headerlines',1);
      fclose(fp);
      set(handles.uitable5,'Data',cell2mat(Data))
     otherwise
         msgbox('Wrong File','File Open Error'); 
         return;
end
handles.GeneratorData=Data;
guidata(hObject,handles);

function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');

L=length(filename);
if L<6
    errodlg('Wrong File','File Open Error'); 
    return;
end
wenjian = [pathname filename];
set(handles.edit6,'string',wenjian);
test=filename(1,L-3:L);
switch test
    case 'xlsx'
      data=xlsread(wenjian);
      set(handles.uitable6,'data',data); 
    case '.txt'
      fp =fopen(wenjian);
      Data=textscan(fp,'%.0f%.0f%.0f%.0f%.0f%f%f%f%f%*[^\n]','delimiter',',','headerlines',1);
      fclose(fp);
      set(handles.uitable6,'Data',cell2mat(Data))
     otherwise
         msgbox('Wrong File','File Open Error'); 
         return;
end
handles.LineData=Data;
guidata(hObject,handles);

function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');

L=length(filename);
if L<6
    errodlg('Wrong File','File Open Error'); 
    return;
end
wenjian = [pathname filename];
set(handles.edit7,'string',wenjian);
test=filename(1,L-3:L);
switch test
    case 'xlsx'
      data=xlsread(wenjian);
      set(handles.uitable7,'data',data);
    case '.txt'
      fp =fopen(wenjian);
      Data=textscan(fp,'%.0f%.0f%.0f%.0f%.0f%f%f%f%f%*[^\n]','delimiter',',','headerlines',1);
      fclose(fp);
      set(handles.uitable7,'Data',cell2mat(Data))
     otherwise
         msgbox('Wrong File','File Open Error'); 
         return;
end
handles.TransformerData=Data;
guidata(hObject,handles);

function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Store the data of the main interface tables in folder 'GridData1'
      data1=get(handles.uitable1,'Data');
      dlmwrite('Area.txt',data1);% The text file can also be stored in a certain path like C:\Users\xzc\Desktop\HITS_V2.0\GridData1\Area.txt
      data2=get(handles.uitable2,'Data');
      dlmwrite('Bus.txt',data2);
      data3=get(handles.uitable3,'Data');
      dlmwrite('CriticalLoad.txt',data3);
      data4=get(handles.uitable4,'Data');
      dlmwrite('DispatchableLoad.txt',data4);
      data5=get(handles.uitable5,'Data');
      dlmwrite('Generator.txt',data5);
      data6=get(handles.uitable6,'Data');
      dlmwrite('Line.txt',data6);
      data7=get(handles.uitable7,'Data');
      dlmwrite('Transformer.txt',data7);

      [filename, pathname] = uigetfile({'*.xlsx'; '*.xls'; '*.txt'}, 'Read Files');
      a_temp=filename;
      b_temp=abs(a_temp);
      b_temp=b_temp(1:length(b_temp)-2);
      c_temp=char(b_temp); %name of m file of case
      if ~isempty(c_temp)          
          link_sum0=Random_Edge_Cascading(c_temp);
          
          mpc = loadcase(c_temp);
          [link_RG,degree_Rank]=Relationship_Graph(link_sum0,size(mpc.branch,1));
      end
      
% clear all;clc;
GRMs_FileNameDef;
GRMs_PathAdd;
Initialization;


%%
%*********** Loop Initialization ***********
GRM1_LoopInit;
Grid=Grid;
while ~isempty(find(GetStepValue(Grid,'Grid.Generator.IsOn',Grid.step)==0))
    GRM1_StepInit;
    while IncreaseDepthFlag==1
        %**************************** Loop function *****************************
        % Incerase search depth and recalculate it when no generator is crancked!
        %************************************************************************
        GRM1_UpdateDepth;%;
%         Grid=feval(GRM1_WaitForStart,Grid);
        Grid=GRM1_WaitForStart(Grid);
        Grid = GRM1_SortGenerators(Grid);
%         Grid=feval(GRM1_WaitForStart,Grid);%Get all generators and loads waiting for start within the search depth!
%         Grid=feval(GRM1_SortGenerators,Grid);
        GRM1_CrankInit;
        while CrankGeneratorFlag==1&&Grid.NextGeneratorReference<=length(Grid.GeneratorsWaitForStart)
            %**************************** Loop function *****************************
            %     Crank next generator when present generator cannot be cranked!
            %************************************************************************
%             Grid=feval(GRM1_EnergizePath,Grid);
            Grid=GRM1_EnergizePath(Grid);
%             Grid=feval(GRM1_OPF,Grid);
            Grid=GRM1_OPF(Grid);
            GRM1_DisPlayProgress;
            GRM1_CrankJudgment;
            Grid=GRM1_CalculateTime(Grid);
%             Grid=feval(GRM1_UpdateGrid,Grid);
            Grid=GRM1_UpdateGrid(Grid);
            Grid.NextGeneratorReference=Grid.NextGeneratorReference+1;
        end
    end
    if isempty(GetStepValue(Grid,'Grid.Generator.P_Out',Grid.step))&&nnz(Grid.Bus.BusSet)==max(Grid.Bus.ID)
        disp('FAILED!!');
        break;
    end
end
%%
%Finished!
GRMs_ShowResults;


[A,Order]=sort(Generator_StartTime);
[B,Order]=sort(Order); 

open('hits1.fig');
h=guihandles;
set(h.edit1,'string',Generator_StartTime);
set(h.edit3,'string',cell2mat(struct2cell(Time)));
set(h.edit2,'string',num2str(Order'));
set(h.edit4,'string',num2str(Grid.AllBus(:,2)));
set(h.edit5,'string',num2str(Grid.AllBus(:,3)));

if ~isempty(c_temp) 
%     load link_sum0_test.mat;
%     [link_RG,degree_Rank]=Relationship_Graph(link_sum0,38);
    set(h.uitable3,'Data',link_RG);
    set(h.uitable4,'Data',degree_Rank);
else
    msgbox('If you want to use the Influence Graph function, please load the related m file of case when push the "Compute" button.','Attention!','modal');
end

axes(h.axes2)
second=Grid.AllBus(:,2);
m=length(Grid.AllBus(:,2));
for i=1:m
    n(i)=i;
end


bar(n, second);
xlabel('Bus NO.');
ylabel('Voltge(p.u.)'); 
axis([0 m+1 0 1.2]);
set(gca,'YTick',[0:0.1:1.2]);
guidata(hObject,handles);

Voltage=Grid.AllBus(:,2);
Angle=Grid.AllBus(:,3);
handles.Generator_StartTime=Generator_StartTime;
handles.Time=Time;
handles.Order=Order;
handles.Voltage=Voltage;
handles.Angle=Angle;
handles.c_temp=c_temp;
if ~isempty(c_temp)  
    handles.link_RG=link_RG;
    handles.degree_Rank=degree_Rank;
end
guidata(hObject,handles);




% --------------------------------------------------------------------
function menu_Callback(hObject, eventdata, handles)
% hObject    handle to menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Save the result in the folder 'Results'
Generator_StartTime=handles.Generator_StartTime;
Time=handles.Time;
Order=handles.Order;
Voltage=handles.Voltage;
Angle=handles.Angle;
c_temp=handles.c_temp;

dlmwrite('Generator_StartTime.txt',Generator_StartTime,'delimiter',' ','newline','pc');% The text file can also be stored in a certain path like C:\Users\xzc\Desktop\HITS_V2.0\Results\Generator_StartTime.txt.

dlmwrite('Time.txt',cell2mat(struct2cell(Time)),'delimiter',' ','newline','pc');

dlmwrite('Order.txt',Order,'delimiter',' ','newline','pc');

dlmwrite('Voltage.txt',Voltage,'delimiter',' ','newline','pc');

dlmwrite('Angle.txt',Angle,'delimiter',' ','newline','pc');

if ~isempty(c_temp)
    degree_Rank=handles.degree_Rank;
    link_RG=handles.link_RG;
    dlmwrite('degree_Rank.txt',degree_Rank,'delimiter',' ','newline','pc');
    save IG_matrix.mat link_RG;
end
% --------------------------------------------------------------------
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close;


% --------------------------------------------------------------------
function About_Callback(hObject, eventdata, handles)
% hObject    handle to About (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
open('hits2.fig');
hh=guihandles;
set(hh.text2,'string',{ '************************************************************',...
    '<HITS>',...
    'Generic Restoration Milestones',...
    'Version 2.0',...
    'April 2022',...
    'Copyright (c) 2011-2022, The University of Hong Kong.'... 
    'Copying and distribution of this file, with or without modification, are permitted in any medium following the LICENSE and this notice are preserved. This file is offered as-is, without any warranty.',...
    'Author: Zhicheng Xu, Zhijun Qin, Jiazuo Hou, Qinfei Long and Yunhe Hou',...
    'Email: yhhou@eee.hku.hk',...
    'Website: https://www.eee.hku.hk/~yhhou/',...
    '************************************************************' });
