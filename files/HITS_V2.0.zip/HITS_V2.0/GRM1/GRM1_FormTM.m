function Grid=GRM1_FormTM(Grid)
%%
%%****************** Input ******************
nBuses          =   max(Grid.Bus.ID);
nLines          =   max(Grid.Line.ID);
nTrans          =   max(Grid.Transformer.ID);
lineI           =   Grid.Line.I;
lineJ           =   Grid.Line.J;
tranI           =   Grid.Transformer.I;
tranJ           =   Grid.Transformer.J;
lineOn          =   GetStepValue(Grid,'Grid.Line.IsOn',Grid.step-1);
tranOn          =   GetStepValue(Grid,'Grid.Transformer.IsOn',Grid.step-1);

%%
%%****************** Calculate ******************
TM = sparse ( eye(nBuses, nBuses) );
for i=1:nLines
    if lineOn(i) == 1
        TM ( lineI(i), lineJ(i) ) = 1;
        TM ( lineJ(i), lineI(i) ) = 1;
    end
end

for i=1:nTrans
    if tranOn(i) == 1
        TM ( tranI(i), tranJ(i) ) = 1;
        TM ( tranJ(i), tranI(i) ) = 1;
    end
end
%%
%****************** Output ******************
Grid.TM         =   TM;