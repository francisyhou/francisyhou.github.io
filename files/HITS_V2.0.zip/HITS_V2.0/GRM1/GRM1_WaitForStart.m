function Grid=GRM1_WaitForStart(Grid)
%%
%%****************** Input ******************
genOn           =   GetStepValue(Grid,'Grid.Generator.IsOn',Grid.step-1);
busOn           =   GetStepValue(Grid,'Grid.Bus.IsOn',Grid.step-1);
disLoadOn       =   GetStepValue(Grid,'Grid.Load.DispatchableLoad.IsOn',Grid.step-1);
criLoadOn       =   GetStepValue(Grid,'Grid.Load.CriticalLoad.IsOn',Grid.step-1);
%%
%%****************** Calculate ******************
% TM
Grid= GRM1_FormTM(Grid);

% Get all buses which are connected with the block within D lines
Grid= GRM1_DepthBusSet(Grid);

%Update busOn
% for i=1:length(Grid.Bus.BusSet)
%     busOn(Grid.Bus.BusSet(i))=1;
% end
%busOn(Grid.Bus.BusSet)=1;

% Find all the generators which are connected with the block within D lines, and get rid of all the genrators which have already been cranked.
toNBSGenBusSet     =   intersect(Grid.Generator.BusID(Grid.Generator.NotBlackStartID),Grid.Bus.BusSet);
genFilter          =   ismember(Grid.Generator.BusID, toNBSGenBusSet);
toNBSGenSet        =   Grid.Generator.ID( find(genFilter>0) );
toNBSGenSet        =   intersect(toNBSGenSet, Grid.Generator.ID (find(genOn==0)));



% Find all the dispatchable loads which are connected with the block within D lines
toDispatchableLoadBusSet    =   intersect(Grid.Load.DispatchableLoad.BusID, Grid.Bus.BusSet);
loadFilter                  =   ismember(Grid.Load.DispatchableLoad.BusID, toDispatchableLoadBusSet);
toDispatchableLoadSet       =   Grid.Load.DispatchableLoad.ID( find(loadFilter>0) );
disLoadOn(toDispatchableLoadSet)=1;  


% Find all the critical loads which are connected with the block within D lines
toCriLoadBusSet         = intersect(Grid.Load.CriticalLoad.BusID, Grid.Bus.BusSet);
loadFilter              = ismember(Grid.Load.CriticalLoad.BusID, toCriLoadBusSet);
toCriLoadSet            = Grid.Load.CriticalLoad.ID( find(loadFilter>0) );
criLoadOn(toCriLoadSet) =1;

%%
%%****************** Output ******************
Grid=UpdateStepValue(Grid,'Grid.Load.DispatchableLoad.IsOn',Grid.step,disLoadOn);
Grid=UpdateStepValue(Grid,'Grid.Load.CriticalLoad.IsOn',Grid.step,criLoadOn);

Grid.GeneratorsWaitForStart=toNBSGenSet;
%Sort Grid.GeneratorsWaitForStart
Grid.CriticalLoadWaitForStart=toCriLoadSet;
Grid.DispatchableLoadWaitForStart=toDispatchableLoadSet;




