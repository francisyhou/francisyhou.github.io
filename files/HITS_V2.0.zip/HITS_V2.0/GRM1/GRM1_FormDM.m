function Grid=GRM1_FormDM(Grid)
%%
%%****************** Input ******************
nBuses          =   max(Grid.Bus.ID);
nLines          =   max(Grid.Line.ID);
nTrans          =   max(Grid.Transformer.ID);
lineI           =   Grid.Line.I;
lineJ           =   Grid.Line.J;
lineB           =   Grid.Line.B;
tranI           =   Grid.Transformer.I;
tranJ           =   Grid.Transformer.J;
lineOn          =   GetStepValue(Grid,'Grid.Line.IsOn',Grid.step-1);
tranOn          =   GetStepValue(Grid,'Grid.Transformer.IsOn',Grid.step-1);

%%
%%****************** Calculate ******************
DM = 999 * ones ( nBuses, nBuses );
for i=1:nLines
    if lineOn(i) == 0
        DM ( lineI(i), lineJ(i) ) = lineB(i);
        DM ( lineJ(i), lineI(i) ) = lineB(i);
    else
        DM ( lineI(i), lineJ(i) ) = 0;
        DM ( lineJ(i), lineI(i) ) = 0;
    end
end

for i=1:nTrans
    if tranOn(i) == 0
        DM ( tranI(i), tranJ(i) ) = 10;
        DM ( tranJ(i), tranI(i) ) = 10;
    else
        DM ( tranI(i), tranJ(i) ) = 0;
        DM ( tranJ(i), tranI(i) ) = 0;
    end
end
%%
%****************** Output ******************
Grid.DM         =   DM;