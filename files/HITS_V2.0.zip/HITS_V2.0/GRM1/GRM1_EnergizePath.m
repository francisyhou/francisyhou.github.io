function Grid=GRM1_EnergizePath(Grid)
%%
%%****************** Input ******************
busOn               =   GetStepValue(Grid,'Grid.Bus.IsOn',Grid.step-1);
busOn_last          =   find(GetStepValue(Grid,'Grid.Bus.IsOn',Grid.step-1)~=0);
busOn_present       =   Grid.Bus.BusSet;
fromBus             =   Grid.Generator.BusID(Grid.Generator.BlackStartID);
lineOn              =   GetStepValue(Grid,'Grid.Line.IsOn',Grid.step-1);
lineOn_tem          =   lineOn;
tranOn              =   GetStepValue(Grid,'Grid.Transformer.IsOn',Grid.step-1);
tranOn_tem          =   tranOn;
genOn               =   GetStepValue(Grid,'Grid.Generator.IsOn',Grid.step-1);
time_last           =   GetStepValue(Grid,'Grid.Time',Grid.step-1);
busOn_time          =   GetStepValue(Grid,'Grid.Bus.TimeOn',Grid.step-1);

toDispatchableLoadSet   =Grid.DispatchableLoadWaitForStart;


toCriLoadSet        =   Grid.CriticalLoadWaitForStart;


toNBSGenID          =   Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference);

%%
%%****************** Calculate ******************
genOn(Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference))   =   1;

toNBSGenBus=Grid.Generator.BusID(toNBSGenID);
toCriLoadSetBusSet=Grid.Load.CriticalLoad.BusID(toCriLoadSet);
toDispatchableLoadBusSet=Grid.Load.DispatchableLoad.BusID(toDispatchableLoadSet);

TOBUS=[toNBSGenBus;toCriLoadSetBusSet;toDispatchableLoadBusSet];
TOBUS=unique(TOBUS);

%Form DM
Grid=GRM1_FormDM(Grid);

branch_time=0;



for i=1:nnz(TOBUS)%Calculate line, transformer bus on or not
    time=0;
    toBus=TOBUS(i);
    [energize_path, c_cost] = GRM1_Dijkstra(fromBus, toBus, Grid.DM);
    for j=1:length(energize_path)-1
        lineID=GRM1_GetBranchID(Grid.Line,energize_path(j),energize_path(j+1));
        if lineID>0
            if lineOn_tem(lineID)==1
                continue;
            end
            lineOn(lineID)=1;
            busOn(energize_path(j+1))=1;
            time=time+Grid.Line.Time(lineID);
            busOn_time(energize_path(j+1))=time_last+time;
            continue;
        end
        tranID=GRM1_GetBranchID(Grid.Transformer,energize_path(j),energize_path(j+1));
        if tranID>0
            if tranOn_tem(tranID)==1
                continue;
            end
            tranOn(tranID)=1;
            busOn(energize_path(j+1))=1;
            time=time+Grid.Transformer.Time(tranID);
            busOn_time(energize_path(j+1))=time_last+time;
            continue;
        end
    end
    if time>branch_time
        branch_time=time;
    end
end

%busOn_time(find(busOn==0))=0;

%%
%%****************** Output ******************
Grid.BranchTime             =   branch_time;
Grid.Bus.BusOnTemp          =   busOn;
Grid.Bus.TimeOnTemp         =   busOn_time;
Grid.Transformer.TranOnTemp =   tranOn;
Grid.Line.LineOnTemp        =   lineOn;
Grid.Generator.GenOnTemp    =   genOn;
%Grid.Generator.StartTime(Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference))=time_last+branch_time;

