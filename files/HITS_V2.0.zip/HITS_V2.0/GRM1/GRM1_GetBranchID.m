function ID=GRM1_GetBranchID(Data,left,right)
%%
%Data  :    Grid.Line or Grid.Transformer
lineI=Data.I;
lineJ=Data.J;
for i=1:length(lineI)
    if left==lineI(i)&&right==lineJ(i)||left==lineJ(i)&&right==lineI(i)
        ID=i;
        return;
    end
end
ID=0;
