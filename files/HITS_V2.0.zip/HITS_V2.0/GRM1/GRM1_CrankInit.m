Grid.NextGeneratorReference     =   1;
Grid.Parameters.KLast           =   0;
Grid.Parameters.KPresent        =   0;