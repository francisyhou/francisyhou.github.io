if Grid.Success==1
    disp(['Try cranking the generator ID=',num2str(Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference)),', and SUCCEED!']);
else
    disp(['Try cranking the generator ID=',num2str(Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference)),', and FAILED!']);
end

