%%
%*************************** Variables *************************** 
Grid.step               =   Grid.step+1;
IncreaseDepthFlag       =   1;
CrankGeneratorFlag      =   1;
Grid.Bus.BusSet         =   [];
Grid=UpdateStepValue(Grid,'Grid.Parameters.D',Grid.step,Grid.Parameters.Depth-1);
%%
%*************************** Display *************************** 
disp(' ');
disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~');
disp(['Step=',num2str(Grid.step)]);