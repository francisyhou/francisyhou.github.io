function Grid=GRM1_CalculateTime(Grid)
%%
%%****************** Input ******************
%Gird;
%%
%%****************** Calculate ******************
[ genTimeRamping, k0 ]= GRM1_GenTimeRamping(Grid);

%%
%%****************** Output ******************

Grid.GeneratorTimePresent       =   max(genTimeRamping);
Grid.Parameters.KPresent        =   k0;
