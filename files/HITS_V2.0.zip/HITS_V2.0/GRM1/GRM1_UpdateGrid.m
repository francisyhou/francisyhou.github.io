function Grid=GRM1_UpdateGrid(Grid)
t_present   =   GetStepValue(Grid,'Grid.Time',Grid.step-1)+Grid.BranchTime+Grid.GeneratorTimePresent;
%t           =   GetStepValue(Grid,'Grid.Time',Grid.step);
if isempty(GetStepValue(Grid,'Grid.Generator.P_Out',Grid.step))||Grid.Generator.RampingRate(Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference))>Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference-1)
    Grid    =   UpdateStepValue(Grid,'Grid.Generator.P_Out',Grid.step,Grid.Generator.P_OutPresent);
    Grid    =   UpdateStepValue(Grid,'Grid.Load.DispatchableLoad.P_Out',Grid.step,Grid.Load.DispatchableLoad.P_OutPresent);
    Grid    =   UpdateStepValue(Grid,'Grid.Load.DispatchableLoad.Q_Out',Grid.step,Grid.Load.DispatchableLoad.Q_OutPresent);
    Grid    =   UpdateStepValue(Grid,'Grid.Time',Grid.step,t_present);
    Grid.Generator.StartTime(Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference))=t_present-Grid.GeneratorTimePresent;
    Grid    =   UpdateStepValue(Grid,'Grid.Bus.IsOn',Grid.step,Grid.Bus.BusOnTemp );
    Grid    =   UpdateStepValue(Grid,'Grid.Bus.TimeOn',Grid.step,Grid.Bus.TimeOnTemp);
    Grid    =   UpdateStepValue(Grid,'Grid.Transformer.IsOn',Grid.step,Grid.Transformer.TranOnTemp);
    Grid    =   UpdateStepValue(Grid,'Grid.Line.IsOn',Grid.step,Grid.Line.LineOnTemp);
    Grid    =   UpdateStepValue(Grid,'Grid.Generator.IsOn',Grid.step,Grid.Generator.GenOnTemp);
    Grid.Parameters.KLast=Grid.Parameters.KPresent;
end

