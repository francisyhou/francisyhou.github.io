function Grid=GRM1_FormCM(Grid)
%%
%%****************** Input ******************
nBuses          =   max(Grid.Bus.ID);
nLines          =   max(Grid.Line.ID);
nTrans          =   max(Grid.Transformer.ID);
lineI           =   Grid.Line.I;
lineJ           =   Grid.Line.J;
tranI           =   Grid.Transformer.I;
tranJ           =   Grid.Transformer.J;

%%
%%****************** Calculate ******************
CM = sparse ( eye(nBuses, nBuses) );

for i=1:nLines
    CM ( lineI(i), lineJ(i) ) = 1;
    CM ( lineJ(i), lineI(i) ) = 1;
end

for i=1:nTrans
    CM ( tranI(i), tranJ(i) ) = 1;
    CM ( tranJ(i), tranI(i) ) = 1;
end
%%
%****************** Output ******************
Grid.CM         =   CM;