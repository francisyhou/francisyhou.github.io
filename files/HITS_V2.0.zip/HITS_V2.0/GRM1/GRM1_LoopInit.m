%%
%*********************** Loop Parameters ************************
Grid.step               =   0;
IncreaseDepthFlag       =   1;
CrankGeneratorFlag      =   1;
NextGeneratorReference  =   1;
%%
%*************************** Form CM ***************************
Grid=GRM1_FormCM(Grid);

%%
%*************************** Display ***************************
disp('                      Start')