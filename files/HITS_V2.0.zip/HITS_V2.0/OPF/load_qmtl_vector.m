function [vector] = load_qmtl_vector(filename);

k = textread(filename);

nrow =  k(1,1);

[nnz_real, tmp] =  size(k);
nnz_real = nnz_real -1;

vector = sparse(nrow, 1);

for(i=1:nnz_real)
    vector( k(i+1, 1), 1 ) = k(i+1, 2);
end