function [dhx,dgx] = opf_grade (n, NG,NGi,PV,PVi,G, B ,e, f, lines, I, J, Gij1, Gij2, Bij1, Bij2); 

lines = 0;

Ee = sparse(1:n, 1:n, e, n, n);
Ef = sparse(1:n, 1:n, f, n, n);

tmp1 = G*Ee  + B*Ef;
tmp2 = B*Ee  - G*Ef;



dp_de_  =  -( tmp1);
dp_de_diag = -(G*e-B*f);
dp_de_ = dp_de_ + sparse(1:n, 1:n, dp_de_diag, n, n);


dp_df_ = tmp2;
dp_df_diag = -(G*f+B*e);
dp_df_ = dp_df_ + sparse(1:n,1:n, dp_df_diag, n, n);


dp_dPg_ = sparse(NGi, 1:NG, ones(NG, 1), n, NG );

dp_dQg_ =  sparse(n,PV) ;


dq_de_ = tmp2;
dq_de_diag = G*f + B*e;
dq_de_ = dq_de_ + sparse(1:n, 1:n, dq_de_diag, n, n);

dq_df_ = tmp1;
dq_df_diag = - ( G*e - B*f);
dq_df_ = dq_df_ + sparse(1:n, 1:n, dq_df_diag, n, n);

dq_dPg_ = sparse(n,NG);


dq_dQg_ = sparse(PVi, 1:PV, ones(PV, 1), n, PV ) ;


dhx = [dp_de_,  dq_de_;...
       dp_df_,  dq_df_;...
       dp_dPg_', dq_dPg_';...
       dp_dQg_', dq_dQg_'];

%dgx1=Gij1*(diag(2*e(I)-e(J)))-Gij2*diag(e(I))   +    Bij1*diag(f(J))-Bij2*diag(f(I));
%dgx2=Gij1*(diag(2*f(I)-f(J)))-Gij2*diag(f(I))   -    Bij1*diag(e(J))+Bij2*diag(e(I));
dgx1 = [];
dgx2 = [];


dgx = [sparse(n, NG), sparse(n, PV), sparse(1:n, 1:n, 2*e, n, n), dgx1;...
       sparse(n, NG), sparse(n, PV), sparse(1:n, 1:n, 2*f, n, n), dgx2;...
       sparse(1:NG, 1:NG, ones(NG, 1), NG, NG), sparse(NG, PV+n+lines);...
       sparse(PV, NG), sparse(1:PV, 1:PV, ones(PV, 1), PV, PV), sparse(PV, n+lines)];
