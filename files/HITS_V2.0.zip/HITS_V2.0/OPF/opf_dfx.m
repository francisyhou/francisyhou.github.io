function [dfx] = opf_dfx(question, n, NG, PV, PGs, NGi, NGa, NGb, NGc, e, f,  G, B);

dfx = sparse(2*n+PV+NG, 1);

switch question;
	case '1'; 
        dfx = [sparse(n,1); sparse(n,1); ones(NG,1); sparse(PV,1)];    
	case '2'; 
        dfx = -[4*(sum((diag(e)*G-G*diag(e)).')).';  4*(sum((diag(f)*G-G*diag(f)).')).';  sparse(NG+PV,1)];
	case '3'; 
        dfx =  [4*(sum((diag(e)*B-B*diag(e)).')).';  4*(sum((diag(f)*B-B*diag(f)).')).';  sparse(NG+PV,1)];    
	case '4'; 
        dfx = [sparse(n,1); sparse(n,1); 2*NGc(NGi).*PGs(NGi)+NGb(NGi); sparse(PV,1)]; 
	end;
