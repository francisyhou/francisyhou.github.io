function [ Lx, Ly, Lz, Lw, Ll, Lu, Pij] = opf_disp (VV, dfx, dhx, dgx,n, NG,PV, G, B, e, f, l,u, y, z, w, ue, ...
          PGs, Qpv, NGPmin,NGPmax,PVQmin,PVQmax, PG, QG, PD, QD,...
          NGi, PVi, lines, I,J);

Lx = dfx - dhx*y - dgx*(z+w);

Ly_p = PGs - 1.0*PD - e.*(G*e-B*f) - f.*(G*f + B*e);
Ly_q = Qpv - 1.0*QD - f.*(G*e-B*f) + e.*(G*f + B*e);
Ly = [Ly_p; Ly_q];

Pij = [e(I).*e(I) + f(I).*f(I)-e(I).*e(J)-f(I).*f(J)].*diag(G(I,J))...
    + [e(I).*f(J)-e(J).*f(I)].*diag(B(I,J));

Lz_p = PGs(NGi) - l(1:NG) - NGPmin(NGi);
Lz_q = Qpv(PVi) - l(NG+1:NG+PV) - PVQmin(PVi);
Lz_v = e.*e + f.*f - l(NG+PV+1:NG+PV+n) - VV.Min*VV.Min;
if isfield(VV,'Bus') ~= 0 %some voltages are specified
    for i = 1 : length(VV.Bus)
        Lz_v(VV.Bus(i)) =  Lz_v(VV.Bus(i)) + VV.Min*VV.Min - VV.Bus_min(i)*VV.Bus_min(i);
    end
end
    
%Lz_l = Pij - l(NG+PV+n+1:NG+PV+n+lines) + 10000;
Lz_l = [];
Lz = [Lz_p; Lz_q; Lz_v;Lz_l];

Lw_p = PGs(NGi) + u(1:NG) - NGPmax(NGi);
Lw_q = Qpv(PVi) + u(NG+1:NG+PV) - PVQmax(PVi);
Lw_v = e.*e + f.*f + u(NG+PV+1:NG+PV+n) - VV.Max*VV.Max;
if isfield(VV,'Bus') ~= 0 %some voltages are specified
    for i = 1 : length(VV.Bus)
        Lw_v(VV.Bus(i)) =  Lw_v(VV.Bus(i)) + VV.Max*VV.Max - VV.Bus_max(i)*VV.Bus_max(i);
    end
end


%Lw_l = Pij + u(NG+PV+n+1:NG+PV+n+lines) - 10000;
Lw_l = [];
Lw = [Lw_p; Lw_q; Lw_v;Lw_l];

%Ll = (diag(l)*diag(z)* sparse(ones(n+NG+PV+lines,1)) - ue);
%Lu = (diag(u)*diag(w)* sparse(ones(n+NG+PV+lines,1)) + ue);
Ll = (diag(l)*diag(z)* sparse(ones(n+NG+PV,1)) - ue);
Lu = (diag(u)*diag(w)* sparse(ones(n+NG+PV,1)) + ue);