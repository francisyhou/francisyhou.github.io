function [d2fx] = opf_d2fx(question, nnn, n, NG, PV, NGa, NGb, NGc, NGi, G, B);

d2fx = sparse(nnn, nnn);

switch question;
case '1';    
    ;     
case '2'; 
    tmp=4*(G-diag(diag(G)));
    tmp=tmp-diag(sum(tmp));
    d2fx=[tmp, sparse(n,n), sparse(n, NG+PV);
          sparse(n,n), tmp, sparse(n, NG+PV);
          sparse(NG+PV, nnn)];
case '3';        
    tmp=4*(B-diag(diag(B)));
    tmp=-tmp+diag(sum(tmp));
    d2fx=[tmp, sparse(n,n), sparse(n, NG+PV);
          sparse(n,n), tmp, sparse(n, NG+PV);
          sparse(NG+PV, nnn)];
case '4';       
    d2fx(n*2+1:n*2+NG , n*2+1:n*2+NG)=sparse(diag(2*NGc(NGi)));
end;