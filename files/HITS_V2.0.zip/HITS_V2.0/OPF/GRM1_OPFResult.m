

function [ genPLast, genPNow, dispLoadP, dispLoadQ ]= GRM1_OPFResult(Grid);
%%****************** Input ******************
NGi                 =   Grid.Generator.BusID;
genOn               =   Grid.Generator.GenOnTemp;
genPNow             =   GetStepValue(Grid,'Grid.Generator.P_Out',Grid.step-1);
toNBSGenID          =   Grid.GeneratorsWaitForStart(Grid.NextGeneratorReference);
toNBSGenBus         =   Grid.Generator.BusID(toNBSGenID);


disLoadOn           =   GetStepValue(Grid,'Grid.Load.DispatchableLoad.IsOn',Grid.step);
NdispLi             =   Grid.Load.DispatchableLoad.BusID;
dispLoadP           =   GetStepValue(Grid,'Grid.Load.DispatchableLoad.P_Out',Grid.step-1);
dispLPmin           =   Grid.Load.DispatchableLoad.Pmin;
dispLPmax           =   Grid.Load.DispatchableLoad.Pmax;
dispLoadQ           =   GetStepValue(Grid,'Grid.Load.DispatchableLoad.Q_Out',Grid.step-1);
dispLQmin           =   Grid.Load.DispatchableLoad.Qmin;
dispLQmax           =   Grid.Load.DispatchableLoad.Qmax;
dispLBlks           =   Grid.Load.DispatchableLoad.Blocks;

busOnId             =   find(Grid.Bus.BusOnTemp~=0);
           
all_bus             =   Grid.AllBus;
%%
genPLast = genPNow;

% �������������ĳ�����ע�⣬������������opfģ�����Ը��ɳ��֣�����Ӧע����ֵ�ķ���
genPNow ( toNBSGenID) = - all_bus ( find( busOnId == toNBSGenBus ), 6 );

% ���������Ѿ�Ͷ�˻���ĳ���
genOnId  = find ( genOn > 0 );  
nGen   = nnz(genOnId);
for i=1:nGen
    if genOnId(i)==toNBSGenID ; 
        continue;
    end;
    genPNow ( genOnId(i) ) = all_bus ( find( busOnId == NGi(  genOnId(i) ) ), 4 );
end

% ���������Ѿ�Ͷ�˸��ɵĹ��ʣ�ע�⣬�ɵ��ȸ�����opf���Է�������֣�Ӧע����ֵ�ķ���
disLoadOnId  = find ( disLoadOn > 0 );  
nLoad   = nnz(disLoadOnId);
for i=1:nLoad
    LP = - all_bus ( find( busOnId == NdispLi(  disLoadOnId(i) ) ), 4 );
    LQ = - all_bus ( find( busOnId == NdispLi(  disLoadOnId(i) ) ), 5 );
    
    LPBlk = ( dispLPmax(disLoadOnId(i)) - dispLPmin(disLoadOnId(i)) ) / dispLBlks( disLoadOnId(i) ) ;
    LQBlk = ( dispLQmax(disLoadOnId(i)) - dispLQmin(disLoadOnId(i)) ) / dispLBlks( disLoadOnId(i) ) ;
    
    if ( LP - dispLoadP ( disLoadOnId(i) ) ) > 0.9 * LPBlk  | ( LQ - dispLoadQ ( disLoadOnId(i) ) ) > 0.9 * LQBlk ;
       dispLoadP ( disLoadOnId(i) ) = dispLoadP ( disLoadOnId(i) ) + LPBlk;
       dispLoadQ ( disLoadOnId(i) ) = dispLoadQ ( disLoadOnId(i) ) + LQBlk;
    end
end

