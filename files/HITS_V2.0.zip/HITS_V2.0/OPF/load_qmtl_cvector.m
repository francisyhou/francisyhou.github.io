function [vector] = load_qmtl_cvector(filename);

% k = textread(filename);
k = textread(filename,'', 'delimiter', '(  , ) ', 'emptyvalue', 0);
% [a,e ,b,f, c] = textread(filename, '%u %s %f %s %f',5);
nrow =  k(1,1);

[nnz_real, tmp] =  size(k);
nnz_real = nnz_real -1;

vector = sparse(nrow, 1);

for(i=1:nnz_real)
    vector( k(i+1, 1), 1 ) = k(i+1, 2)+j*k(i+1, 3);
    
end


