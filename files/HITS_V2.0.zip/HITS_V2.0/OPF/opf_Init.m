function [e, f, l, u, y, z, w, nnn, mmm, rrr, PGs, Qpv] = opf_Init (n, ...
    NG, PV, PG, QG, NGi, PVi, NGPmin, NGPmax, PVQmin, PVQmax, lines); 

e = sparse(ones(n,1));  
f = sparse(n,1);        
PGs = sparse(n,1);     
Qpv = sparse(n,1);      
%X = [e;f;PGs;Qpv];     

nnn  = 2*n + NG + PV;
mmm  = 2*n;          
%rrr  = n+NG+PV+lines;
rrr  = n+NG+PV;

l = sparse(ones(rrr,1));     
u = sparse(ones(rrr,1));     
y = 0.1*sparse(ones(mmm,1)); 
z = sparse(ones(rrr, 1));    
w = -sparse(ones(rrr, 1));   

PGs = PG;
Qpv = QG;
PGs(NGi)=(NGPmin(NGi)+NGPmax(NGi))/2;
Qpv(PVi)=(PVQmin(PVi)+PVQmax(PVi))/2;