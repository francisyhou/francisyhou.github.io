function varargout = tread (varargin);

error(nargchk(1,inf,nargin));

% if (exist(varargin{1}) ~= 2 | exist(fullfile(cd,varargin{1})) ~= 2) & ~isempty(which(varargin{1}))
%     varargin{1} = which(varargin{1});
% end

if exist(varargin{1}) ~= 2
    error('File not found.');
end

if nargout == 0
    nlhs = 1;
else
    nlhs = nargout;
end

[varargout{1:nlhs}]=dataread('file',varargin{:});