function [e, f, PGs, Qpv, l, u, y, z, w, success] = opf_correct(F, d2fx, dgx, dhx, dfx, ue, ...
                                          Ly, Lz, Lw, Ll, Lu, nnn, mmm, rrr, n, NG, PV,...
                                          l, u, y, z, w, e, f, PGs, Qpv, NGi, PVi, balance, ttt);

success = 1;
H = F +  dgx*diag(w./u-z./l)*(dgx') - d2fx;

%Wx = [H dhx; dhx' sparse(2*n, 2*n)];
Wx = [H dhx; dhx' ttt];

if (condest(diag(u)) < 1e-20 |condest(diag(l)) < 1e-20)
    success = 0;
    return;
end

if (condest(diag(u)) > 1e+20 |condest(diag(l)) > 1e+20)
    success = 0;
    return;
end

PS = dfx - dhx*y - dgx*( -(diag(z./l))*(Lz) + (diag(w./u)) *(Lw) - ue*(inv(diag(u))-inv(diag(l)))*sparse(ones(rrr,1)) );

Wx(n+balance,:) = 0;
Wx(:,n+balance) = 0;
Wx(n+balance,n+balance) = 1;
PS(n+balance) = 0;


dxdy = Wx\full([PS; -Ly]);
% pp = amd(Wx);
% [dxdy, fl] = ldl (Wx, pp, full([PS; -Ly]));

de = dxdy(1:n);
df = dxdy(n+1: n+n);
dPg = dxdy(n+n+1:n+n+NG);
dQv = dxdy(n+n+NG+1:n+n+NG+PV);
dy  = dxdy(nnn+1:nnn+mmm);
dx = dxdy(1:nnn);



    
dz = -inv(diag(l))*diag(z)*(dgx.')*dx-inv(diag(l))*(diag(z)*Lz+Ll);
dw = inv(diag(u))*diag(w)*(dgx.')*dx+inv(diag(u))*(diag(w)*Lw-Lu);
dl = (dgx.')*dx+Lz;
du = -((dgx')*dx+Lw);
    

[i,v] = find( dl < 0 );
step_p1 = min(  [( l(i)./ (-dl(i)) )] );
[i,v] = find( du < 0 );
step_p2 = min(  [( u(i)./ (-du(i)) )] );
step_p = 0.9995*min([step_p1; step_p2; 1]);
    

[i,v] = find( dz < 0 );
step_d1 = min(  [( z(i)./ (-dz(i)) )] );
[i,v] = find( dw > 0 );
step_d2 = min(  [( w(i)./ (-dw(i)) )] );
step_d = 0.9995*min([step_d1; step_d2; 1]);
    

e = e + step_p*de;
f = f + step_p*df;
PGs(NGi) = PGs(NGi) + step_p*dPg;
Qpv(PVi) = Qpv(PVi) + step_p*dQv;
    
l = l + step_p*dl;
u = u + step_p*du;

y = y + step_d*dy;
z = z + step_d*dz;
w = w + step_d*dw;