function [matrix] = load_qmtl_matrix(filename);

k = textread(filename);

row = k(1,1);
col = k(1,2);
nnz = k(1,3);

[nnz_real, tmp] =  size(k);
nnz_real = nnz_real -1;

ii = k(2:nnz_real+1, 1);
jj = k(2:nnz_real+1, 2);
xx = k(2:nnz_real+1, 3);

matrix = sparse(ii, jj, xx, row, col);
