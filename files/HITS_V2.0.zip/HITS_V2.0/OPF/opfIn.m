function [n,lines,balance,SB,ktt,cp,ee,type,...
        line,linei,linej,lineY,lineb,...
        branch,branchi,branchY,...
        trans,transi,transj,transk,transY,...
        PQ,PQi,PG,QG,PD,QD,PV,PVi,PVv,PVQmin,PVQmax,...
        NG,NGi,NGa,NGb,NGc,NGPmin,NGPmax,all_bus] = opfIn(a);  

% filename=uigetfile('*.*');
% tic
% a=opfTread(filename);

n=a(1,1);
lines=a(1,2);
balance=a(1,3);
SB=a(1,4);
ktt=a(1,5);
cp=a(1,6);
ee=a(2,1);
type=a(2,2);

line=0;
for k=3:3+lines;
    if a(k,1)~=0;
        line=line+1;
    else;
        break;
    end;
end;
k=2+line;
linei=a(3:k,2);
linej=a(3:k,3);
lineY=(a(3:k,4)-j*a(3:k,5))./(a(3:k,4).^2+a(3:k,5).^2);
lineb=a(3:k,6);

branch=0;
for k=4+line:4+line+lines;
    if a(k,1)~=0;
        branch=branch+1;
    else;
        break;
    end;
end;
k1=4+line;
k2=3+line+branch;
branchi=a(k1:k2,1);
branchY=a(k1:k2,2);

trans=0;
for k=5+line+branch:5+line+branch+lines;
    if a(k,1)~=0;
        trans=trans+1;
    else;
        break;
    end;
end;
k1=5+line+branch;
k2=4+line+branch+trans;
transi=a((k1:k2),2);
transj=a((k1:k2),3);
transk=a((k1:k2),6);
transY=(a((k1:k2),4)-j*a((k1:k2),5))./(a((k1:k2),4).^2+a((k1:k2),5).^2);

k=6+line+branch+trans;
PQ=0;
for k1=k:k+n;
    if a(k1,1)~=0;
        PQ=PQ+1;        
    else;
        break;
    end;
end;
PG=sparse(n,1);
QG=sparse(n,1);
PD=sparse(n,1);
QD=sparse(n,1);
k1=k+PQ-1;
PQi=a(k:k1,1);
PG(PQi,:)=a(k:k1,2)/SB;
QG(PQi,:)=a(k:k1,3)/SB;
PD(PQi,:)=a(k:k1,4)/SB;
QD(PQi,:)=a(k:k1,5)/SB;
all_bus = zeros(length(PQi(:,1)),7);
all_bus(:,1) = PQi;
all_bus(:,4) = PG;
all_bus(:,5) = QG;
all_bus(:,6) = PD;
all_bus(:,7) = QD;


k=7+line+branch+trans+PQ;
PV=0;
for k1=k:k+n;
    if a(k1,1)~=0;
        PV=PV+1;     
    else;
        break;
    end;
end;
PVQmin=sparse(n,1);
PVQmax=sparse(n,1);
PVv=sparse(n,1);
k1=k+PV-1;
PVi=a(k:k1,1);
PVv(PVi,:)=a(k:k1,2);
PVQmin(PVi,:)=a(k:k1,3)/SB;
PVQmax(PVi,:)=a(k:k1,4)/SB;

k=8+line+branch+trans+PQ+PV;
NG=0;
for k1=k:k+n;
    if a(k1,1)~=0;
        NG=NG+1;        
    else;
        break;
    end;
end;
NGa=sparse(n,1);
NGb=sparse(n,1);
NGc=sparse(n,1);
NGPmin=sparse(n,1);
NGPmax=sparse(n,1);
k1=k+NG-1;
NGi=a(k:k1,1);
NGa(NGi,:)=a(k:k1,2);
NGb(NGi,:)=a(k:k1,3);
NGc(NGi,:)=a(k:k1,4);
NGPmin(NGi,:)=a(k:k1,5)/SB;
NGPmax(NGi,:)=a(k:k1,6)/SB;