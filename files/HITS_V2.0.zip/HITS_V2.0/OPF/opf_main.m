function [all_bus,success] = opf_main(VV,a)


question = '4'; % 1-min(PG);
                % 2-min(PLoss)
                % 3-min(QLoss)
                % 4-min(Fcost) 

%--------------------------------------------------------------------------
% n  :   number of buses
% lines: number of lines
% balance  
% SB      
% ktt: max iterations 
% cp : central parameter
% ee : 1E-5
% line,linei,linej,lineY,lineb  :   line parameters
% branch,branchi,branchY        :   
% trans,transi,transj,transk,transY: transformer parameters
% NG,NGi,NGa,NGb,NGc,NGPmin,NGPmax : generator parameters
 [n,line,balance,SB,ktt,cp,ee,type,...
  lines,I,J,lineY,lineb,...
  branch,branchi,branchY,...
  trans,transi,transj,transk,transY,...
  PQ,PQi,PG,QG,PD,QD,PV,PVi,PVv,PVQmin,PVQmax,...
  NG,NGi,NGa,NGb,NGc,NGPmin,NGPmax,all_bus] = opfIn(a);

all_bus;
[Y,G,B] = opf_Y (n,I,J,lineY,lineb,...
                 transi,transj,transY,transk,branchi,branchY);
%--------------------------------------------------------------------------
[e, f, l, u, y, z, w, nnn, mmm, rrr, PGs, Qpv] = opf_Init (n, NG, PV, ...
    PG, QG, NGi, PVi, NGPmin, NGPmax, PVQmin, PVQmax, lines);

[d2fx] = opf_d2fx(question, nnn, n, NG,PV, NGa, NGb, NGc, NGi, G, B);

Gij1=sparse(I,1:lines,diag(G(I,J)),n,lines);
Bij1=sparse(I,1:lines,diag(B(I,J)),n,lines);

Gij2=sparse(J,1:lines,diag(G(I,J)),n,lines);
Bij2=sparse(J,1:lines,diag(B(I,J)),n,lines);

mn   = n+NG+PV;  
%mnl  = n+NG+PV+lines;
mnl  = n+NG+PV;
%--------------------------------------------------------------------------
kkk = 0;  

ttt = sparse(1:2*n,1:2*n, 1e-6*ones(2*n, 1), 2*n, 2*n);

CmGap = l'*z - u'*w;

while( kkk<ktt & (CmGap)>= 1E-4)
    
    ue = cp * CmGap/(2*rrr);
        
    [dfx] = opf_dfx(question, n, NG, PV, PGs, NGi, NGa, NGb, NGc, e, f, G, B);
    
    
    [dhx,dgx] = opf_grade(n, NG,NGi,PV, PVi, G, B ,e, f, lines, I,J, Gij1, Gij2, Bij1, Bij2);

    
    [Lx, Ly, Lz, Lw, Ll, Lu, Pij] = opf_disp (VV, dfx, dhx, dgx,n, NG,PV, G, B, e, f, l, u, y, z, w, ue, ...
          PGs, Qpv, NGPmin,NGPmax, PVQmin,PVQmax,PG, QG, PD, QD, ...
          NGi, PVi, lines, I, J);
      
   
    [F] = opf_hess(n, NG, PV, G, B, e, f, y, z, w, mn, mnl, I,J); 
   
    
    [e, f, PGs, Qpv, l, u, y, z, w, success] = opf_correct(F, d2fx, dgx, dhx, dfx, ue, ...
                           Ly, Lz, Lw, Ll, Lu, ...
                           nnn, mmm, rrr, n, NG, PV, ...
                           l, u, y, z, w, e, f, PGs, Qpv, NGi, PVi, balance, ttt);
    
 if (success == 0)
            return;
  end
    kkk = kkk +1;
    
    CmGap = l'*z - u'*w;
    fx  = sum( NGc(NGi).*PGs(NGi).*PGs(NGi)+ NGb(NGi).*PGs(NGi) + NGa(NGi) ) ;
end
%toc


V = e+j*f;
switch question;
	case '1'; 
        fx  = sum(PGs(NGi))     
	case '2'; 
        fx = -real(sum(sum((diag(V')*(diag(V)*G-G*diag(V))-(diag(V)*G-G*diag(V))*diag(V')))))
	case '3'; 
        fx = real(sum(sum((diag(V')*(diag(V)*B-B*diag(V))-(diag(V)*B-B*diag(V))*diag(V')))))    
	case '4'; 
        PGs(NGi);
        Qpv(PVi);
        fx  = sum( NGc(NGi).*PGs(NGi).*PGs(NGi)+ NGb(NGi).*PGs(NGi) + NGa(NGi) ); 
	end;
    [angl,mod] = cart2pol(e,f);
   all_bus(:,2) = mod;
   all_bus(:,3) = angl;
   all_bus(:,4) = PGs;
   all_bus(:,5) = Qpv;

   
   [Lx, Ly, Lz, Lw, Ll, Lu, Pij] = opf_disp (VV, dfx, dhx, dgx,n, NG,PV, G, B, e, f, l, u, y, z, w, ue, ...
          PGs, Qpv, NGPmin,NGPmax, PVQmin,PVQmax,PG, QG, PD, QD, ...
          NGi, PVi, lines, I, J);
   
   success = 0;
   max(abs([Lx;Ly;Lz;Lw;Ll;Lu]));  
if (max(abs([Lx;Ly;Lz;Lw;Ll;Lu]))<=ee)
       success = 1;
   end
  % Pij = [e(I).*e(I) + f(I).*f(I)-e(I).*e(J)-f(I).*f(J)].*diag(G(I,J)) + [e(I).*f(J)-e(J).*f(I)].*diag(B(I,J));%��·����
%abs(V)
%V