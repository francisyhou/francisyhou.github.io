function [F] = opf_hess (n, NG, PV,G, B, e, f, y, z, w, mn, mnl, I,J); 

y_p = y(1:n);
y_q = y(n+1:n+n);


y_p_diag = sparse(1:n, 1:n, y_p, n, n);
y_q_diag = sparse(1:n, 1:n, y_q, n, n);


A1 = y_p_diag*(-G) + (-G)*y_p_diag;
B1 = y_p_diag*B - B*y_p_diag;

A2 = y_q_diag*B + B*y_q_diag;
B2 = y_q_diag*G - G*y_q_diag;

F = [A1+A2, B1+B2, sparse(n, NG+PV);... 
      B1'+B2',A1+A2, sparse(n, NG+PV);...
    sparse(NG+PV,2*n+NG+PV)];

d2gx = sparse(1:n, 1:n,(2*(z(NG+PV+1:NG+PV+n)+w(NG+PV+1:NG+PV+n))), 2*n+NG+PV, 2*n+NG+PV );
d2gx = d2gx + sparse(n+1:n+n, n+1:n+n,(2*(z(NG+PV+1:NG+PV+n)+w(NG+PV+1:NG+PV+n))), 2*n+NG+PV, 2*n+NG+PV );

%K1 = diag(diag(G(I,J)))*(z(mn+1:mnl)+w(mn+1:mnl));
%C= -sparse(J,I,K1,n,n)-sparse(I,J,K1,n,n)+...
%    2*diag(sum(sparse(J,I,K1,n,n)));    

%K2=diag(diag(B(I,J)))*(z(mn+1:mnl)+w(mn+1:mnl));
%D=sparse(I,J,K2,n,n)-sparse(J,I,K2,n,n);

F = F + d2gx;

%F = F + d2gx + [C, D, sparse(n, NG+PV);...
 %              D', C, sparse(n, NG+PV);...
  %             sparse(NG+PV, 2*n+PV+NG)];


