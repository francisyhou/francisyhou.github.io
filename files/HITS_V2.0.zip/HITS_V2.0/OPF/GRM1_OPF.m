function Grid=GRM1_OPF(Grid)
%%
%%****************** Input ******************
%Gird
%%
%%****************** Calculate ******************
[opfData]= GRM1_OPFDataPrepare(Grid);
VV.Min = 0.90;
VV.Max = 1.1;
[Grid.AllBus,success] = opf_main(VV, opfData);
[ genPLast, genPNow, dispLoadP, dispLoadQ ]= GRM1_OPFResult(Grid);
%%
%%****************** Output ******************
Grid.Success=success;
Grid.Generator.P_OutPresent=genPNow;
Grid.Load.DispatchableLoad.P_OutPresent=dispLoadP;
Grid.Load.DispatchableLoad.Q_OutPresent=dispLoadQ;


