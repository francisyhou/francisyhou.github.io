function [Y,G,B] = opf_Y (n,linei,linej,lineY,lineb,transi,transj,transY,transk,branchi,branchY);  

Y=-sparse(linei,linej,lineY,n,n)-sparse(linej,linei,lineY,n,n)+sparse(linei,linei,lineY+j*lineb,n,n)+sparse(linej,linej,lineY+j*lineb,n,n);

Y=Y+sparse(branchi,branchi,j*branchY,n,n);

Y=Y-sparse(transi,transj,transY./transk,n,n)-...
    sparse(transj,transi,transY./transk,n,n)+...
    sparse(transi,transi,transY./transk.^2,n,n)+...
    sparse(transj,transj,transY,n,n);

G=real(Y);
B=imag(Y);