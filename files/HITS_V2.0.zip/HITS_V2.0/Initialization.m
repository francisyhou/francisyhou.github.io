%%
%******************* Variables of GRMs *******************
VariablesInit;
%%
%***************** Display informations *****************
GRMs_DisplayInformation(GRMs);