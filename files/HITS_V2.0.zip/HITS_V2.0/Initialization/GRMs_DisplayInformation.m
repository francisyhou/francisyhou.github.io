function []=GRMs_DisplayInformation(GRMsInfo)
%%
%GRMs_INFORMATION displays some information of Generic Restoration Milestones
%%
disp(['************************************************************'])
disp([blanks(30-floor(1+length(GRMsInfo.Name)/2)),'<',GRMsInfo.Name,'>'])
disp([blanks(30-floor(4+length(GRMsInfo.Version)/2)),'Version ',GRMsInfo.Version])
disp([blanks(30-floor(length(GRMsInfo.Date)/2)),GRMsInfo.Date])
CopyrightInformation=GRMsInfo.CopyrightInfo;
for i=1:floor(length(CopyrightInformation)/60)
    RowEnd='';
    try 
        if isletter(CopyrightInformation(i*60))&& isletter(CopyrightInformation(i*60+1))
            RowEnd='-';
        end
    catch
    end
   disp([CopyrightInformation((i-1)*60+1:i*60),RowEnd]); 
end
try 
    disp(CopyrightInformation(i*60+1:end));
catch
end

disp(['Host:         Matlab ',version]);
disp(['Session:      ', datestr(now,0)]);
disp(['Path:         ',pwd]);
disp(['Author:       ',GRMsInfo.Author])
disp(['Email:        ',GRMsInfo.EmailAddress])
disp(['Wbesite:      ',GRMsInfo.Website])
disp(['************************************************************'])
disp(' ');