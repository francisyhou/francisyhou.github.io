![HITS]

Contributing
------------

Primary developers:
- Zhicheng Xu
- Yunhe Hou

Other contributors:
- Zhijun Qin
- Jiazuo Hou
- Qinfei Long


Publications and Tech Notes
---------------------------

1.  Hou, Yunhe, Chen-Ching Liu, Kai Sun, Pei Zhang, Shanshan Liu, 
    and Dean Mizumura. "Computation of milestones for decision support 
    during system restoration." In 2011 IEEE Power and Energy Society 
    General Meeting, pp. 1-10. IEEE, 2011.

2.  Liu, Haoming, Xingying Chen, Kun Yu, and Yunhe Hou. 
    "The control and analysis of self-healing urban power grid." 
    IEEE Transactions on smart grid 3, no. 3 (2012): 1119-1129.

3.  Liu, Shanshan, Yunhe Hou, Chen-Ching Liu, and Robin Podmore. 
    "The healing touch: Tools and challenges for smart grid restoration." 
    IEEE power and energy magazine 12, no. 1 (2013): 54-63.

4.  Sun, Kai, Yunhe Hou, Wei Sun, and Junjian Qi. "Power system control 
    under cascading failures: understanding, mitigation, and system 
    restoration." John Wiley & Sons, 2019.

5.  Long, Qinfei, Zhiyuan Ma, Feng Liu, Shengwei Mei, and Yunhe Hou. 
    "Analyzing Patterns Transference and Mitigation of Cascading Failures 
    with Interaction Graphs." In 2021 IEEE PES Innovative Smart Grid 
    Technologies Europe (ISGT Europe), pp. 01-05. IEEE, 2021.


E-mail Lists
------------

yhhou@eee.hku.hk


License and Terms of Use
------------------------

HITS is distributed as open-source under the [3-clause BSD license].

