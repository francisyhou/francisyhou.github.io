function [Grid]=GRMs_Preprocessing(Grid)
%%
%*************************** Generator ***************************
Grid.Generator.BlackStartID=Grid.Generator.ID(find(Grid.Generator.BlackStartFlag==1));
Grid.Generator.NotBlackStartID=Grid.Generator.ID(find(Grid.Generator.BlackStartFlag==0));
Grid.Generator.IsOn.Step_0(Grid.Generator.BlackStartID)=1;
Grid.Generator.StartTime(Grid.Generator.BlackStartID)=0;

%%
%*************************** Bus ***************************
BlackStartID        =   find(Grid.Generator.BlackStartFlag==1);
Grid.Bus.BusOnID    =   Grid.Generator.BusID(BlackStartID);
for i=1:length(BlackStartID)
    Grid.Bus.IsOn.Step_0(find(Grid.Bus.ID==Grid.Bus.BusOnID(i)))   =    1;
    Grid.Bus.TimeOn.Step_0(Grid.Bus.ID==Grid.Bus.BusOnID(i))       =    Grid.Generator.TimeToCrank(BlackStartID(i));
end
%%
%*************************** Line ***************************
Grid.Line.UseableLine=Grid.Line.OriginalID(find(Grid.Line.OriginalUseableFlag==1));
for i=1:length(Grid.Line.UseableLine)
    TempID=find(Grid.Line.OriginalID==Grid.Line.UseableLine(i));
    Grid.Line.ID(i)=i;
    Grid.Line.Name(i)=Grid.Line.OriginalName(TempID);
    Grid.Line.I(i)=Grid.Line.OriginalI(TempID);
    Grid.Line.J(i)=Grid.Line.OriginalJ(TempID);
    Grid.Line.R(i)=Grid.Line.OriginalR(TempID);
    Grid.Line.X(i)=Grid.Line.OriginalX(TempID);
    Grid.Line.B(i)=Grid.Line.OriginalB(TempID);
    Grid.Line.Time(i)=Grid.Line.OriginalTime(TempID);
end
Grid.Line.IsOn.Step_0=zeros(size(Grid.Line.ID));
%%
%*************************** Transformer ***************************
Grid.Transformer.UseableTrans=Grid.Transformer.OriginalID(find(Grid.Transformer.OriginalUseableFlag==1));
for i=1:length(Grid.Transformer.UseableTrans)
    TempID=find(Grid.Transformer.OriginalID==Grid.Transformer.UseableTrans(i));
    Grid.Transformer.ID(i)=i;
    Grid.Transformer.Name(i)=Grid.Transformer.OriginalName(TempID);
    Grid.Transformer.I(i)=Grid.Transformer.OriginalI(TempID);
    Grid.Transformer.J(i)=Grid.Transformer.OriginalJ(TempID);
    Grid.Transformer.R(i)=Grid.Transformer.OriginalR(TempID);
    Grid.Transformer.X(i)=Grid.Transformer.OriginalX(TempID);
    Grid.Transformer.K(i)=Grid.Transformer.OriginalK(TempID);
    Grid.Transformer.Time(i)=Grid.Transformer.OriginalTime(TempID);
end
Grid.Transformer.IsOn.Step_0=zeros(size(Grid.Transformer.ID));
%%
%*************************** Time of Step_0 ***************************
%Grid.Time.Step_0=Grid.Time.Step_0+max(Grid.Generator.TimeToCrank(Grid.Generator.BlackStartID));

