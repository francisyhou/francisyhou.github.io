function [GeneratorData]=GRMs_GetData_Generator(GeneratorFileName)

fid = fopen(GeneratorFileName);
Data=textscan(fid,'%d%s%d%f%d%f%f%f%f%f%f%d%*[^\n]','delimiter',',');
fclose(fid);
% ,'headerlines',1
GeneratorData.ID=Data{1};
GeneratorData.Name=Data{2};
GeneratorData.BusID=Data{3};
GeneratorData.Capacity=Data{4};
GeneratorData.BlackStartFlag=Data{5};
GeneratorData.RampingRate=Data{6};
GeneratorData.StartRequirement=Data{7};
GeneratorData.TimeToCrank=Data{8};
GeneratorData.Pmin=Data{9};
GeneratorData.Pmax=Data{10};
GeneratorData.MinOutputRate=Data{11};
GeneratorData.Priority=Data{12};

GeneratorData.IsOn.Step_0=zeros(size(Data{1}));
GeneratorData.P_Out.Step_0=zeros(size(Data{1}));
GeneratorData.StartTime=zeros(size(Data{1}));