function [LineData]=GRMs_GetData_Line(LineFileName)

fid = fopen(LineFileName);
Data=textscan(fid,'%d%s%d%d%d%f%f%f%f%*[^\n]','delimiter',',');
fclose(fid);
% ','headerlines',1
LineData.OriginalID=Data{1};
LineData.OriginalName=Data{2};
LineData.OriginalUseableFlag=Data{3};
LineData.OriginalI=Data{4};
LineData.OriginalJ=Data{5};
LineData.OriginalR=Data{6};
LineData.OriginalX=Data{7};
LineData.OriginalB=Data{8};
LineData.OriginalTime=Data{9};

%LineData.IsOn.Step_0=zeros(size(Data{1}));