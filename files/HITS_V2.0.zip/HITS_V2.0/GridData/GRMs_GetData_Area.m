function [AreaData]=GRMs_GetData_Area(AreaFileName)

fid = fopen(AreaFileName);
Data=textscan(fid,'%d%s%d%*[^\n]','delimiter',',');
fclose(fid);

AreaData.ID=Data{1};
AreaData.Name=Data{2};
AreaData.Buses=Data{3};

% ,'headerlines',1
% fp =fopen(wenjian);
% i=1;
% while ~feof(fp)
% strl{i}=fgetl(fp);
% i=i+1;
% end
% % [m,n]=size(strl);
% % str=strl(2:m,:);
% fclose(fp);
% 
% set(handles.edit1,'string',strl)

% Data=xlsread(AreaFileName);
% AreaData.ID=Data(1);
% AreaData.Name=Data(2);
% AreaData.Buses=Data(3);
