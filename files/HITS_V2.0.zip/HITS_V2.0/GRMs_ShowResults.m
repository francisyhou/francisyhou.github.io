disp(' ')
disp('--------------------------------------------------------------------')
Generator_StartTime=Grid.Generator.StartTime;
Generator_StartTime=Generator_StartTime'
Time=Grid.Time
b=struct2cell(Grid.Generator.IsOn);
c=[];
for k=1:length(b)
    c=[c,(b{k})];
end
Generator_IsOn=c';
