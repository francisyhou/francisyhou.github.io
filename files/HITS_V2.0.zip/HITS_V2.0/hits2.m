function varargout = hits2(varargin)
% HITS2 MATLAB code for hits2.fig
%      HITS2, by itself, creates a new HITS2 or raises the existing
%      singleton*.
%
%      H = HITS2 returns the handle to a new HITS2 or the handle to
%      the existing singleton*.
%
%      HITS2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HITS2.M with the given input arguments.
%
%      HITS2('Property','Value',...) creates a new HITS2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hits2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hits2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hits2

% Last Modified by GUIDE v2.5 23-Jun-2022 16:51:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hits2_OpeningFcn, ...
                   'gui_OutputFcn',  @hits2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hits2 is made visible.
function hits2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hits2 (see VARARGIN)

% Choose default command line output for hits2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hits2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = hits2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
set(handles.text2,'string',{ '************************************************************',...
    '<HITS>',...
    'Generic Restoration Milestones',...
    'Version 2.0',...
    'April 2022',...
    'Copyright (c) 2011-2022, The University of Hong Kong.'... 
    'Copying and distribution of this file, with or without modification, are permitted in any medium following the LICENSE and this notice are preserved. This file is offered as-is, without any warranty.',...
    'Author: Zhicheng Xu, Zhijun Qin, Jiazuo Hou, Qinfei Long and Yunhe Hou',...
    'Email: yhhou@eee.hku.hk',...
    'Website: https://www.eee.hku.hk/~yhhou/',...
    '************************************************************' });
