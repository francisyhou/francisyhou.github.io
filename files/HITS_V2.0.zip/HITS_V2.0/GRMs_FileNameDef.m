 %%
%  ***************** Data Files *****************
AreaFile                =           'Area.txt';
BusFile                 =           'Bus.txt';
CriticaLoadFile         =           'CriticalLoad.txt';
DispatchableLoadFile    =           'DispatchableLoad.txt';
GeneratorFile           =           'Generator.txt';
LineFile                =           'Line.txt';
TransformerFile         =           'Transformer.txt';

%%
%***************** Function Files *****************
GRM1_WaitForStart       =       'GRM1_WaitForStart';
GRM1_EnergizePath       =       'GRM1_EnergizePath';
GRM1_OPF                =       'GRM1_OPF';
GRM1_SortGenerators     =       'GRM1_SortGenerators';
GRM1_UpdateGrid         =       'GRM1_UpdateGrid';
%%
%***************** Other Files *****************
