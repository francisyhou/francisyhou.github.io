if isempty(Grid.Bus.BusOnTemp) ...
        ||length(Grid.Bus.BusSet)<max(Grid.Bus.ID)%If all buses can be charged when depth is D, then there is no need to increase D.
    Grid=UpdateStepValue(Grid,'Grid.Parameters.D',Grid.step,GetStepValue(Grid,'Grid.Parameters.D',Grid.step)+1);%Grid.Parameters.D.Step_i=Grid.Parameters.D.Step_i+1;
    if GetStepValue(Grid,'Grid.Parameters.D',Grid.step)==1
        disp('~~~~~~~~~~~~~~~~~~~~~~~~~');
        disp(['D=',num2str(GetStepValue(Grid,'Grid.Parameters.D',Grid.step))]);
    else
        disp(['Increase depth. D=',num2str(GetStepValue(Grid,'Grid.Parameters.D',Grid.step))]);
    end
else
    if nnz(Grid.Bus.BusSet)==max(Grid.Bus.ID)
        break;
    end
end