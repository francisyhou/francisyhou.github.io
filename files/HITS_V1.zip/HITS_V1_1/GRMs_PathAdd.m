%%
%******************** Add path ********************
path(path,[pwd,'\OPF']);
path(path,[pwd,'\Initialization']);
path(path,[pwd,'\StepValue']);
path(path,[pwd,'\GridData']);
path(path,[pwd,'\GRM1']);
%%
%************* Add paths of all the cases************
P=dir([pwd,'\GridData']);
P_Size=size(P);
for i=3:P_Size(1)
    if P(i,1).isdir==1
        path(path,[pwd,'\GridData','\',P(i,1).name]);
    end
end
%%
