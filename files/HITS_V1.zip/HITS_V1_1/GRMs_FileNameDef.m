%%
%***************** Data Files *****************
AreaFile                =           'RTS24_area.txt';
BusFile                 =           'RTS24_bus.txt';
CriticaLoadFile         =           'RTS24_criticalLoad.txt';
DispatchableLoadFile    =           'RTS24_dispatchableLoad.txt';
GeneratorFile           =           'RTS24_gen.txt';
LineFile                =           'RTS24_line.txt';
TransformerFile         =           'RTS24_tran.txt';

%%
%***************** Function Files *****************
GRM1_WaitForStart       =       'GRM1_WaitForStart';
GRM1_EnergizePath       =       'GRM1_EnergizePath';
GRM1_OPF                =       'GRM1_OPF';
GRM1_SortGenerators     =       'GRM1_SortGenerators';
GRM1_UpdateGrid         =       'GRM1_UpdateGrid';
%%
%***************** Other Files *****************
