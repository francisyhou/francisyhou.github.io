function [DisData]=GRMs_GetData_DispatchableLoad(DisLoadFileName)

fid = fopen(DisLoadFileName);
Data=textscan(fid,'%d%s%d%f%f%f%f%f%f%f%*[^\n]','delimiter',',','CommentStyle','%');
fclose(fid);

DisData.ID=Data{1};
DisData.Name=Data{2};
DisData.BusID=Data{3};
DisData.P=Data{4};
DisData.Pmin=Data{5};
DisData.Pmax=Data{6};
DisData.Q=Data{7};
DisData.Qmin=Data{8};
DisData.Qmax=Data{9};
DisData.Blocks=Data{10};

DisData.P_Out.Step_0=zeros(size(Data{1}));
DisData.Q_Out.Step_0=zeros(size(Data{1}));
DisData.IsOn.Step_0=zeros(size(Data{1}));