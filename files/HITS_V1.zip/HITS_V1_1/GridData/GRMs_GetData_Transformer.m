function [TransformerData]=GRMs_GetData_Transformer(TransformerFileName)

fid = fopen(TransformerFileName);
Data=textscan(fid,'%d%s%d%d%d%f%f%f%f%*[^\n]','delimiter',',','CommentStyle','%');
fclose(fid);

TransformerData.OriginalID=Data{1};
TransformerData.OriginalName=Data{2};
TransformerData.OriginalUseableFlag=Data{3};
TransformerData.OriginalI=Data{4};
TransformerData.OriginalJ=Data{5};
TransformerData.OriginalR=Data{6};
TransformerData.OriginalX=Data{7};
TransformerData.OriginalK=Data{8};
TransformerData.OriginalTime=Data{9};

%TransformerData.IsOn.Step_0=zeros(size(Data{1}));