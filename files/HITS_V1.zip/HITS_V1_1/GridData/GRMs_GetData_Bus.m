function [BusData]=GRMs_GetData_Bus(BusFileName)

fid = fopen(BusFileName);
Data=textscan(fid,'%d%s%d%f%f%*[^\n]','delimiter',',','CommentStyle','%');
fclose(fid);

BusData.ID=Data{1};
BusData.Name=Data{2};
BusData.Area=Data{3};
BusData.V=Data{4};
BusData.Deta=Data{5};

BusData.IsOn.Step_0=zeros(size(Data{1}));
BusData.TimeOn.Step_0=zeros(size(Data{1}));