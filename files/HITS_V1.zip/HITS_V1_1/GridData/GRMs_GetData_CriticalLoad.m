function [CriData]=GRMs_GetData_CriticalLoad(CriLoadFileName)

fid = fopen(CriLoadFileName);
Data=textscan(fid,'%d%s%d%f%f%d%*[^\n]','delimiter',',','CommentStyle','%');
fclose(fid);

CriData.ID=Data{1};
CriData.Name=Data{2};
CriData.BusID=Data{3};
CriData.P=Data{4};
CriData.Q=Data{5};
CriData.Priority=Data{6};

%CriData.IsOn.Step_0=zeros(size(Data{1}));
% CriData.P_Out.Step_0=CriData.P;
% CriData.Q_Out.Step_0=CriData.Q;
CriData.IsOn.Step_0=zeros(size(Data{1}));