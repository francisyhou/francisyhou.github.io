function [AreaData]=GRMs_GetData_Area(AreaFileName)

fid = fopen(AreaFileName);
Data=textscan(fid,'%d%s%d%*[^\n]','delimiter',',','CommentStyle','%');
fclose(fid);

AreaData.ID=Data{1};
AreaData.Name=Data{2};
AreaData.Buses=Data{3};