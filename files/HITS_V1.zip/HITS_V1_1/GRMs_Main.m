%%
%************************ CLEAR ***************************
clear all;
clc;
%%
%********************* Initialization *********************
GRMs_FileNameDef;
GRMs_PathAdd;
Initialization;
%%
%*********** Loop Initialization ***********
GRM1_LoopInit;
while ~isempty(find(GetStepValue(Grid,'Grid.Generator.IsOn',Grid.step)==0))
    GRM1_StepInit;
    while IncreaseDepthFlag==1
        %**************************** Loop function *****************************
        % Incerase search depth and recalculate it when no generator is crancked!
        %************************************************************************
   
        %% ------20190225---------
        % GRM1_UpdateDepth;%;
        if isempty(Grid.Bus.BusOnTemp) ...
                ||length(Grid.Bus.BusSet)<max(Grid.Bus.ID)%If all buses can be charged when depth is D, then there is no need to increase D.
            Grid=UpdateStepValue(Grid,'Grid.Parameters.D',Grid.step,GetStepValue(Grid,'Grid.Parameters.D',Grid.step)+1);%Grid.Parameters.D.Step_i=Grid.Parameters.D.Step_i+1;
            if GetStepValue(Grid,'Grid.Parameters.D',Grid.step)==1
                disp('~~~~~~~~~~~~~~~~~~~~~~~~~');
                disp(['D=',num2str(GetStepValue(Grid,'Grid.Parameters.D',Grid.step))]);
            else
                disp(['Increase depth. D=',num2str(GetStepValue(Grid,'Grid.Parameters.D',Grid.step))]);
            end
        else
            if nnz(Grid.Bus.BusSet)==max(Grid.Bus.ID)
                break;
            end
        end
        
       %%
        Grid=feval(GRM1_WaitForStart,Grid);%Get all generators and loads waiting for start within the search depth!
        Grid=feval(GRM1_SortGenerators,Grid);
        GRM1_CrankInit;
        while CrankGeneratorFlag==1&&Grid.NextGeneratorReference<=length(Grid.GeneratorsWaitForStart)
            %**************************** Loop function *****************************
            %     Crank next generator when present generator cannot be cranked!
            %************************************************************************
            Grid=feval(GRM1_EnergizePath,Grid);
            Grid=feval(GRM1_OPF,Grid);
            GRM1_DisPlayProgress;
            %% ------20190225---------
            % GRM1_CrankJudgment;
            %���������������һ�μ���
            if Grid.Success==1
                IncreaseDepthFlag       =   0;
                CrankGeneratorFlag      =   0;
            else
                Grid.NextGeneratorReference=Grid.NextGeneratorReference+1;
                continue;
            end           
            %������ѭ��Ѱ�һ���
            % if Grid.Success==1
            %     IncreaseDepthFlag       =   0;
            % else
            %     Grid.NextGeneratorReference=Grid.NextGeneratorReference+1;
            %     continue;
            % end
            
           %%
            Grid=GRM1_CalculateTime(Grid);
            Grid=feval(GRM1_UpdateGrid,Grid);
            Grid.NextGeneratorReference=Grid.NextGeneratorReference+1;
        end
    end
    if isempty(GetStepValue(Grid,'Grid.Generator.P_Out',Grid.step))&&nnz(Grid.Bus.BusSet)==max(Grid.Bus.ID)
        disp('FAILED!!');
        break;
    end
end
%%
%Finished!
GRMs_ShowResults;