%%
%***************** Variables of GRMs *****************
GRMs=struct(...
    'Name','HITS',...
    'FullName','Generic Restoration Milestones',...
    'Version','1.0',...
    'Date','AUGUST 2017',...
    'Update','October 2017',...
    'CopyrightInfo','    Copyright (c) 2017-2024, The University of Hong Kong.   Copying and distribution of this file, with or without modification, are permitted in any medium without royalty provided the copyright notice and this notice are preserved. This file is offered as-is, without any warranty.',...
    'PaperName','Computation of Milestones for Decision Support During System Restoration',...
    'Author','Yunhe Hou, Zhijun Qin, Chenchen Qian',...
    'EmailAddress','yhhou@eee.hku.hk',...
    'Website', 'https://www.eee.hku.hk/~yhhou/'...
    );

%%
%***************** Load gird data from files ***************** 
Grid.Area                       =   GRMs_GetData_Area(AreaFile);
Grid.Bus                        =   GRMs_GetData_Bus(BusFile);
Grid.Load.CriticalLoad          =   GRMs_GetData_CriticalLoad(CriticaLoadFile);
Grid.Load.DispatchableLoad      =   GRMs_GetData_DispatchableLoad(DispatchableLoadFile);
Grid.Generator                  =   GRMs_GetData_Generator(GeneratorFile);
Grid.Line                       =   GRMs_GetData_Line(LineFile);
Grid.Transformer                =   GRMs_GetData_Transformer(TransformerFile);

Grid.BranchTime                 =   [];
Grid.Bus.BusOnTemp              =   [];
Grid.Bus.TimeOnTemp             =   [];
Grid.Transformer.TranOnTemp     =   [];
Grid.Line.LineOnTemp            =   [];
Grid.Generator.GenOnTemp        =   [];
%%
%***************** Other parameters ***************** 
Grid.Parameters.Depth           =   1;  %Minimum Search Depth
Grid.Time.Step_0                =   0;  %Time
Grid.Parameters.KLast           =   0;
Grid.Parameters.KPresent        =   0;

%%
%***************** Preprocessing ***************** 
Grid                            =   GRMs_Preprocessing(Grid);
%%
%


