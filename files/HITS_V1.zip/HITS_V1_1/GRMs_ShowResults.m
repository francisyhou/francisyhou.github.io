disp(' ')
disp('--------------------------------------------------------------------')
Generator_StartTime=Grid.Generator.StartTime;
Generator_StartTime=Generator_StartTime'
Time=Grid.Time